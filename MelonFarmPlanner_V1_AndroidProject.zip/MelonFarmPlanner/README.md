# Melon Farm Planner — Android V1

Versi pertama ini menggunakan jadual daripada gambar yang diberikan:
- Hari Ke-
- Hari
- Tarikh
- Kerja
- Racun
- EC
- Timer/Kekerapan
- Tugasan
- Kehadiran
- Penggantian

## Cara bina APK
1. Buka folder ini dalam Android Studio.
2. Tunggu Gradle sync selesai.
3. Pilih `app`.
4. Build > Build APK(s).
5. APK debug akan berada dalam `app/build/outputs/apk/debug/`.

## Nota
Versi ini ialah prototaip V1. Jadual contoh bermula 5 Januari 2027 dan mengandungi template sehingga Hari Ke-35.
