package com.melonfarm.planner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

data class MelonDay(
    val day: Int,
    val date: LocalDate,
    val work: String,
    val pesticide: String = "",
    val ec: String = "",
    val timer: String = "",
    val task: String = "",
    val attendance: String = "",
    val replacement: String = ""
)

private val malayDays = listOf(
    "ISNIN","SELASA","RABU","KHAMIS","JUMAAT","SABTU","AHAD"
)

fun buildSchedule(start: LocalDate): List<MelonDay> {
    // Template berdasarkan jadual pengguna. Hari-hari yang sama kerja dikumpulkan.
    val works = mapOf(
        1 to "TANAM/LILIT", 2 to "TANAM/LILIT", 3 to "TANAM/LILIT",
        4 to "TANAM/LILIT", 5 to "TANAM/LILIT", 6 to "TANAM/LILIT", 7 to "TANAM/LILIT",
        8 to "POTONG SULUR 1-6", 9 to "POTONG SULUR 1-6", 10 to "POTONG SULUR 1-6",
        11 to "POTONG SULUR 1-6", 12 to "POTONG SULUR 1-6", 13 to "POTONG SULUR 1-6", 14 to "POTONG SULUR 1-6",
        15 to "LILIT POKOK", 16 to "LILIT POKOK", 17 to "LILIT POKOK", 18 to "LILIT POKOK", 19 to "LILIT POKOK", 20 to "LILIT POKOK", 21 to "LILIT POKOK",
        22 to "KAHWIN POKOK", 23 to "KAHWIN POKOK", 24 to "KAHWIN POKOK", 25 to "KAHWIN POKOK", 26 to "KAHWIN POKOK", 27 to "KAHWIN POKOK", 28 to "KAHWIN POKOK",
        29 to "KAHWIN POKOK", 30 to "KAHWIN POKOK", 31 to "KAHWIN POKOK", 32 to "KAHWIN POKOK",
        33 to "PILIH BUAH", 34 to "PILIH BUAH", 35 to "PILIH BUAH"
    )
    val ec = when {
        itDay(start, 1) <= 14 -> "1.8"
        else -> "2.0"
    }
    return (1..35).map { d ->
        val e = when (d) {
            in 1..14 -> "1.8"
            in 15..21 -> "2.0"
            in 22..31 -> "2.2"
            else -> "2.5"
        }
        val timer = when {
            d <= 7 -> "1"
            d <= 14 -> "2"
            d <= 21 -> "3"
            d <= 28 -> "4"
            else -> "5"
        }
        val pesticide = when (d) {
            8 -> "1"; 9 -> "2"; 10 -> "3"; 14 -> "4"
            15 -> "5"; 16 -> "6"; 20 -> "7"; 21 -> "1"
            22 -> "2"; 26 -> "3"; 27 -> "4"; 28 -> "5"; 32 -> "6"
            33 -> "7"; 34 -> "1"
            else -> ""
        }
        MelonDay(d, start.plusDays((d-1).toLong()), works[d] ?: "", pesticide, e, timer)
    }
}

fun itDay(start: LocalDate, d: Int) = start.plusDays((d-1).toLong())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MelonFarmApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MelonFarmApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var startDate by remember { mutableStateOf(LocalDate.of(2027, 1, 5)) }
    var schedule by remember(startDate) { mutableStateOf(buildSchedule(startDate)) }
    var showEdit by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("🍈 Melon Farm Planner", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showEdit = true }) {
                        Icon(Icons.Default.Edit, "Edit")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    Icons.Default.Home to "Utama",
                    Icons.Default.CalendarMonth to "Jadual",
                    Icons.Default.People to "Kehadiran",
                    Icons.Default.Settings to "Tetapan"
                ).forEachIndexed { index, pair ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(pair.first, pair.second) },
                        label = { Text(pair.second) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (selectedTab) {
                0 -> Dashboard(schedule, startDate)
                1 -> ScheduleTable(schedule)
                2 -> Attendance(schedule)
                3 -> SettingsScreen(startDate) { startDate = it }
            }
        }
    }

    if (showEdit) {
        AlertDialog(
            onDismissRequest = { showEdit = false },
            title = { Text("Maklumat kebun") },
            text = { Text("Versi 1 menggunakan template jadual daripada gambar yang diberi. Versi seterusnya boleh tambah varieti, bilangan pokok, Brix, berat buah, kos dan keuntungan.") },
            confirmButton = { TextButton(onClick = { showEdit = false }) { Text("OK") } }
        )
    }
}

@Composable
fun Dashboard(schedule: List<MelonDay>, start: LocalDate) {
    val today = LocalDate.now()
    val current = ((java.time.temporal.ChronoUnit.DAYS.between(start, today)).toInt() + 1).coerceIn(1, schedule.size)
    val item = schedule[current - 1]
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("DASHBOARD", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("HARI KE-$current", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(item.work, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Text("Tarikh: ${formatDate(item.date)}")
                Text("EC: ${item.ec}")
                Text("Timer/Kekerapan: ${item.timer}")
                Text("Racun: ${item.pesticide.ifBlank { "-" }}")
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Jadual terdekat", fontWeight = FontWeight.Bold)
        schedule.drop(current - 1).take(5).forEach {
            ListItem(
                headlineContent = { Text("Hari ${it.day} • ${it.work}") },
                supportingContent = { Text("${formatDate(it.date)}  |  EC ${it.ec}  |  Timer ${it.timer}") }
            )
        }
    }
}

@Composable
fun ScheduleTable(schedule: List<MelonDay>) {
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    Column(Modifier.fillMaxSize()) {
        Text("JADUAL TANAMAN", Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
        Row(
            Modifier.horizontalScroll(hScroll).verticalScroll(vScroll)
        ) {
            Column {
                Row(Modifier.background(MaterialTheme.colorScheme.primaryContainer)) {
                    listOf("HARI KE-","HARI","TARIKH","KERJA","RACUN","EC","TIMER/KEKERAPAN","TUGASAN","KEHADIRAN","PENGGANTIAN")
                        .forEach { HeaderCell(it) }
                }
                schedule.forEach { d ->
                    Row {
                        Cell(d.day.toString(), 80)
                        Cell(malayDays[d.date.dayOfWeek.value - 1], 90)
                        Cell(formatDate(d.date), 100)
                        Cell(d.work, 190)
                        Cell(d.pesticide.ifBlank { "" }, 70)
                        Cell(d.ec, 60)
                        Cell(d.timer, 110)
                        Cell(d.task.ifBlank { "-" }, 110)
                        Cell(d.attendance.ifBlank { "-" }, 120)
                        Cell(d.replacement.ifBlank { "-" }, 130)
                    }
                }
            }
        }
    }
}

@Composable
fun HeaderCell(text: String) {
    Box(Modifier.width(if (text.length > 12) 160.dp else 100.dp).padding(6.dp)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
fun Cell(text: String, width: Int) {
    Box(
        Modifier.width(width.dp).height(48.dp).padding(4.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, fontSize = 11.sp)
    }
}

@Composable
fun Attendance(schedule: List<MelonDay>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("KEHADIRAN & PENGGANTIAN", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        schedule.filter { it.task.isNotBlank() }.forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Hari ${it.day} • ${it.work}", fontWeight = FontWeight.Bold)
                    Text(formatDate(it.date))
                    Row {
                        FilterChip(selected = false, onClick = {}, label = { Text("HADIR") })
                        Spacer(Modifier.width(8.dp))
                        FilterChip(selected = false, onClick = {}, label = { Text("GANTI") })
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(start: LocalDate, onDateChange: (LocalDate) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("TETAPAN KEBUN", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Tarikh mula tanaman: ${formatDate(start)}")
        Spacer(Modifier.height(8.dp))
        Text("Versi 1: tarikh contoh 5 Januari 2027.")
        Text("Versi seterusnya: pilih tarikh melalui kalendar dan simpan beberapa kebun.")
    }
}

fun formatDate(date: LocalDate): String =
    "${date.dayOfMonth} ${date.month.getDisplayName(TextStyle.SHORT, Locale("ms", "MY"))}"
